# -*- coding: utf-8 -*-
# @Time    : 2022/5/10 18:02
# @File    : ext.py
"""
全局注册工具
"""
from helper.logger import LOG
from helper.pusher import Pusher

p = Pusher()
