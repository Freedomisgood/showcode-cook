# -*- coding: utf-8 -*-
# @File    : exceptions.py
"""
list some of Exceptions
"""
