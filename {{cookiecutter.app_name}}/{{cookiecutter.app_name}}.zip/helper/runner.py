# -*- coding: utf-8 -*-


class Runner:
    def __init__(self):
        pass

    def run(self):
        pass
