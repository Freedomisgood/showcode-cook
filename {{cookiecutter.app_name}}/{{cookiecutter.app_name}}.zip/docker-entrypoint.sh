#!/bin/bash
set -e

python main.py
